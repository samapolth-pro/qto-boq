﻿# QTO-BOQ installer: copies the app to %LOCALAPPDATA%\Programs\QTO-BOQ and creates shortcuts
$ErrorActionPreference = 'Stop'
$src  = Join-Path $PSScriptRoot 'app'
$dest = Join-Path $env:LOCALAPPDATA 'Programs\QTO-BOQ'
Write-Host 'Installing QTO-BOQ to' $dest
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$appDir = Join-Path $dest 'app'
if (Test-Path $appDir) { Remove-Item $appDir -Recurse -Force }
New-Item -ItemType Directory -Force -Path $appDir | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $appDir -Recurse -Force
Copy-Item -Path (Join-Path $PSScriptRoot 'launch.ps1'),(Join-Path $PSScriptRoot 'uninstall.ps1') -Destination $dest -Force

$ws = New-Object -ComObject WScript.Shell
$targets = @(
  (Join-Path ([Environment]::GetFolderPath('Desktop')) 'QTO-BOQ.lnk'),
  (Join-Path ([Environment]::GetFolderPath('Programs')) 'QTO-BOQ.lnk')
)
foreach ($lnk in $targets) {
  $s = $ws.CreateShortcut($lnk)
  $s.TargetPath = 'powershell.exe'
  $s.Arguments = '-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $dest 'launch.ps1') + '"'
  $s.WorkingDirectory = $dest
  $s.IconLocation = (Join-Path $dest 'app\icon.ico') + ',0'
  $s.Description = 'QTO-BOQ ถอดปริมาณและ BOQ'
  $s.WindowStyle = 7
  $s.Save()
}
Write-Host 'Done. Opening QTO-BOQ...'
Start-Process powershell.exe -ArgumentList ('-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "' + (Join-Path $dest 'launch.ps1') + '"')
