﻿# Opens QTO-BOQ (installed copy) in its own app window: Edge, else Chrome, else default browser.
# Works without any account. Prices update automatically on start when an online price link is set
# (tab "ราคากลาง" > "แหล่งราคาออนไลน์"); without internet it uses the last price list saved on this computer.
$dest = $PSScriptRoot
$page = 'file:///' + ((Join-Path $dest 'app\index.html') -replace '\\','/')
$prof = Join-Path $dest 'profile'
$cands = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$exe = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if ($exe) {
  Start-Process $exe -ArgumentList @("--app=$page", "--user-data-dir=`"$prof`"", '--window-size=1400,900', '--no-first-run', '--disable-features=Translate')
} else {
  Start-Process (Join-Path $dest 'app\index.html')
}
