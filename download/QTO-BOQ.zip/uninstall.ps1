﻿# Removes QTO-BOQ shortcuts and program folder (your saved .qto.json project files are not touched)
$dest = Join-Path $env:LOCALAPPDATA 'Programs\QTO-BOQ'
Remove-Item (Join-Path ([Environment]::GetFolderPath('Desktop')) 'QTO-BOQ.lnk') -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath('Programs')) 'QTO-BOQ.lnk') -ErrorAction SilentlyContinue
Set-Location $env:TEMP
Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
Write-Host 'QTO-BOQ removed.'
